<?php

return [
    [
        'property' => 'og:site_name',
        'content' => '{{SITE_NAME}}',
    ],
    [
        'name' => 'twitter:card',
        'content' => 'summary',
    ],
];