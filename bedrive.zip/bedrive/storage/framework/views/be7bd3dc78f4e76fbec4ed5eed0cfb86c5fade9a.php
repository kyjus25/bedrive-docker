<!doctype html>
<html>
    <head>
        <title class="dynamic-seo-tag"><?php echo e($settings->get('branding.site_name')); ?></title>

        <base href="<?php echo e($htmlBaseUri); ?>">

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="<?php echo e($settings->get('branding.favicon')); ?>">

        <?php echo $__env->yieldContent('progressive-app-tags'); ?>

        <?php echo $__env->yieldContent('angular-styles'); ?>

        
        <?php if($settings->get('branding.use_custom_theme')): ?>
            <link rel="stylesheet" href="<?php echo e(asset('storage/appearance/theme.css')); ?>">
        <?php endif; ?>
        

        <?php if($settings->has('custom_code.load_css')): ?>
            <link rel="stylesheet" href="<?php echo e(asset('storage/custom-code/custom-styles.css')); ?>">
        <?php endif; ?>
	</head>

    <body id="theme">
        <app-root>
            <?php echo $__env->yieldContent('before-loaded-content'); ?>
        </app-root>

        <script>
            window.bootstrapData = "<?php echo $bootstrapData; ?>";
        </script>

        <?php echo $__env->yieldContent('angular-scripts'); ?>

        <?php if($settings->has('custom_code.load_js')): ?>
            <script src="<?php echo e(asset('storage/custom-code/custom-scripts.js')); ?>"></script>
        <?php endif; ?>

        <?php if($code = $settings->get('analytics.tracking_code')): ?>
            <script>
                (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
                })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

                ga('create', '<?php echo e($settings->get('analytics.tracking_code')); ?>', 'auto');
                ga('send', 'pageview');
            </script>
        <?php endif; ?>

        <noscript>You need to have javascript enabled in order to use <strong><?php echo e(config('app.name')); ?></strong>.</noscript>
	</body>
</html>