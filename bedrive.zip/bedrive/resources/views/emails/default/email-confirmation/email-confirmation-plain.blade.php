Verify Your Email Address

Thanks for creating an account with {{ $siteName }} Please click the link below to verify your email address:

{{ url('secure/auth/email/confirm/' . $code) }}