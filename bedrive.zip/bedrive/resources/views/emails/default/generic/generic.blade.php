@extends('emails.default.base')

@section('content')
    <p>{{$body}}</p>
@endsection