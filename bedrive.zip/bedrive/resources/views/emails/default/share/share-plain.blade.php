{{$displayName}} has shared a link with you.

@if($emailMessage)
    {{$emailMessage}}
@endif

View it here: {{$link}}
